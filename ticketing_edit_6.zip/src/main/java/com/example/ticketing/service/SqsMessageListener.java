package com.example.ticketing.service;

import io.awspring.cloud.sqs.annotation.SqsListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

@Service
public class SqsMessageListener {

    @SqsListener("${aws.sqs.queue-name}.fifo")
    public void receiveFifoMessage(@Payload String message) {
        System.out.println("Received FIFO message: " + message);
    }
}

