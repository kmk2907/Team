package com.example.ticketing.service;

import io.awspring.cloud.sqs.annotation.SqsListener;
import org.springframework.stereotype.Service;

@Service
public class SqsMessageListener {

    @SqsListener("${aws.sqs.queue-name}")  // 환경 변수에서 SQS 큐 이름 가져오기
    public void receiveMessage(String message) {
        System.out.println("Received message from SQS: " + message);
    }
}

