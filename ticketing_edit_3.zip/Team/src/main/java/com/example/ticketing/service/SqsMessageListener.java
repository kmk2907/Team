package com.example.ticketing.service;

import org.springframework.messaging.handler.annotation.Header;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.cloud.aws.messaging.listener.annotation.SqsListener;
import org.springframework.cloud.aws.messaging.listener.SqsMessageDeletionPolicy;
import org.springframework.stereotype.Service;

@Service
public class SqsMessageListener {

    @SqsListener(value = "${aws.sqs.queue-name}.fifo", deletionPolicy = SqsMessageDeletionPolicy.ON_SUCCESS)
    public void receiveFifoMessage(@Payload String message,
                                   @Header("MessageDeduplicationId") String dedupId,
                                   @Header("MessageGroupId") String groupId) {
        System.out.println("Received FIFO message: " + message);
        System.out.println("Deduplication ID: " + dedupId);
        System.out.println("Message Group ID: " + groupId);

        // FIFO 큐에서는 MessageGroupId를 기반으로 메시지 순서를 보장하므로,
        // 같은 그룹 ID를 가지는 메시지는 순차적으로 처리됨
    }
}

