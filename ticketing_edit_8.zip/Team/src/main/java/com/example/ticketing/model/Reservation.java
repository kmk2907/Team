package com.example.ticketing.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import java.time.LocalDateTime;  // ✅  LocalDateTime import 추가

@Entity
@Getter
@Setter
@Table(name = "tickets")
public class Reservation {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long userId;
    private String eventName;
    private LocalDateTime reservationTime;  // 예약 시간

    private String seatNumber;
    private String customerName;
    private String phoneNumber;

    public Reservation() {}

    public Reservation(Long userId, String eventName, LocalDateTime reservationTime,
                       String seatNumber, String customerName, String phoneNumber) {
        this.userId = userId;
        this.eventName = eventName;
        this.reservationTime = reservationTime;
        this.seatNumber = seatNumber;
        this.customerName = customerName;
        this.phoneNumber = phoneNumber;
    }
}
