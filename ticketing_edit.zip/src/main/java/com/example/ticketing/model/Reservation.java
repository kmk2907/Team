package com.example.ticketing.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import java.time.LocalDateTime;

@Entity  
@Getter
@Setter
@Table(name = "reservations")  
public class Reservation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) 
    private Long id;

    private Long userId;  // 예약한 사용자 ID
    private String eventName;  // 예약한 이벤트 이름
    private LocalDateTime reservationTime;  // 예약 시간

    private String seatNumber;  // 좌석 번호
    private String customerName;  // 예약자 이름
    private String phoneNumber;  // 예약자 전화번호

    // 기본 생성자
    public Reservation() {}

    // 전체 필드 포함 생성자
    public Reservation(Long userId, String eventName, LocalDateTime reservationTime, 
                       String seatNumber, String customerName, String phoneNumber) {
        this.userId = userId;
        this.eventName = eventName;
        this.reservationTime = reservationTime;
        this.seatNumber = seatNumber;
        this.customerName = customerName;
        this.phoneNumber = phoneNumber;
    }
}

