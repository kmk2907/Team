package com.example.ticketing.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.cloud.aws.messaging.listener.annotation.SqsListener;

@Service
public class SqsMessageListener {

    @Value("${aws.sqs.queue-name}")  // application.yml에서 SQS 큐 이름 가져오기
    private String queueName;

    @SqsListener("${aws.sqs.queue-name}")  // 설정 파일에서 큐 이름을 읽어와서 사용
    public void receiveMessage(@Payload String message) {
        try {
            System.out.println("Received SQS message: " + message);

            // 메시지를 처리하는 로직 추가 (예: DB 저장)
            processMessage(message);

        } catch (Exception e) {
            System.err.println("Error processing SQS message: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void processMessage(String message) {
        // 여기에 메시지를 DB에 저장하는 로직 추가 가능
        System.out.println("Processing message: " + message);
    }
}

