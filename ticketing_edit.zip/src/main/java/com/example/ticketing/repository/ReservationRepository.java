package com.example.ticketing.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.ticketing.model.Reservation;
import java.util.List;

public interface ReservationRepository extends JpaRepository<Reservation, Long> {

    // 특정 사용자(userId)의 예약 목록 조회
    List<Reservation> findByUserId(Long userId);

    // 특정 좌석의 예약 조회
    List<Reservation> findBySeatNumber(String seatNumber);

    // 특정 예약자의 이름으로 예약 조회
    List<Reservation> findByCustomerName(String customerName);
}
